#include <iostream>
#include "collision.h"
using namespace std;

Collision::Collision(){}

void Collision::handleCollision(Object *a, Object *b){}

Collision::~Collision(){}
