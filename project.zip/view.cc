#include <iostream>
#include <ncurses.h>
#include "view.h"
using namespace std;

View::View(){}

void View::init(){}

View::~View(){}
