#include <iostream>
#include <ncurses.h>
#include "model.h"
using namespace std;

Model::Model(){}

void Model::addView(View *view){}

Model::~Model(){}
