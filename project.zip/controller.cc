#include <iostream>
#include <ncurses.h>
#include "controller.h"
using namespace std;

Controller::Controller(){}

void Controller::takeInput(){}

Controller::~Controller(){}
