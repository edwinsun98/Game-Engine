#include <iostream>
#include "statusline.h"
using namespace std;

StatusLine::StatusLine(){}

StatusLine::~StatusLine(){}
