#ifndef REVERSIBLE_H
#define REVERSIBLE_H
using namespace std;

class Reversible{
public:
    virtual bool reverseMovement() = 0;
};

#endif
